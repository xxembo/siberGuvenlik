import hmac
import hashlib

def calculate_hmac(key, message):
    # HMAC için kullanılacak hash algoritmasını seçin
    hash_algorithm = hashlib.sha256
    
    # Anahtarın baytlarını HMAC algoritmasına uygun hale getirin
    key = bytes(key, 'utf-8')
    
    # HMAC hesaplamak için HMAC nesnesini oluşturun
    hmac_obj = hmac.new(key, message.encode('utf-8'), hash_algorithm)
    
    # HMAC değerini hesaplayın
    hmac_value = hmac_obj.digest()
    
    # Hesaplanan HMAC değerini döndürün
    return hmac_value

# Anahtar ve mesajı tanımlayın
key = 'gizlianahtar'
message = 'Merhaba, Dünya!'

# HMAC hesaplaması yapın
hmac_result = calculate_hmac(key, message)

# HMAC değerini yazdırın
print("HMAC Değeri:", hmac_result.hex())